# -*- coding: utf-8 -*-
{
    'name': "Org Grieviance Support",
    'summary': "Org Grieviance Support",
    'description': """Org Grieviance Support""",
    'author': "Harshil",
    'website': "",
    'category': '',
    'version': '17.0.0.0',
    'depends': ['base','website'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False,
}


